def absolute_value(num):
    if num > 0:
        return num
    if num < 0:
        return (num*-1)
num1=int(input("Type in a number-> "))
resultfunc=absolute_value(num1)
print(resultfunc)