def num_status(n):
    if n > 0:
        return "Postive"
    if n < 0:
        return "Negative"
    if n == 0:
        return "Zero"
num=int(input("Type in a number-> "))
resultfunc=num_status(num)
print(resultfunc)