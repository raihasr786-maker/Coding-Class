def calculate_grade(score):
    if score >= 90:
        return "A"
    if (score >= 80) and (score <= 89):
        return "B"
    if (score >= 70) and (score <= 79):
        return "C"
    if (score >= 60) and (score <= 69):
        return "D"
    if score < 60:
        return "Fail"
grade=int(input("Type in your grade-> "))
resultfunc=calculate_grade(grade)
print(resultfunc)